1- write a Java code where a user can create an application and assign it to someone else for approval where it can also be rejected (something like jira)

The trick is that this workflow/Java code need to be delivered by integrating with a business process management tool (jbpm, kie server)

2-write a Java code where a user can issue a card that can be prepaid or credit, in case its a prepaid card it will have maximum top up limit, and many loading limits (monthly, weekly, yearly)

If it's a credit card it will also have limits and fees which will be calculated based on the usage of this card. The trick is to use a rule engine (kie server drools) to apply these rules. Try not to use if conditions and have everything run in the  rule engine and not hard-coded in java


